namespace WebAPI2AuthenticationExample.iOS
{
    static class Constants
    {
		/// <summary>
		/// Update this to your own website server address
		/// </summary>
        public const string BaseAddress = "http://webapi2authenticationexample.azurewebsites.net/";
    }
}